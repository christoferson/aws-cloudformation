exports.handler = async (event) => {
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hi from the ' + event.routeKey + ' route!'),
    };
    return response;
};
